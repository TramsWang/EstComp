package sinc.common;

public class VarIndicator extends ArgIndicator {
    public VarIndicator(String functor, int idx) {
        super(functor, idx);
    }
}
