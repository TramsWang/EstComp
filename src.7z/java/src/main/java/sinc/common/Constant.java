package sinc.common;

public class Constant extends Argument {
    public Constant(int id, String name) {
        super(id, name, false);
    }
}
